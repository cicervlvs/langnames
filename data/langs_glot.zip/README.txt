
Glottolog 4.6 data download
===========================

Data of Glottolog 4.6 is published under the following license:
https://creativecommons.org/licenses/by/4.0/

It should be cited as

Hammarström, Harald & Forkel, Robert & Haspelmath, Martin & Bank, Sebastian. 2022.
Glottolog 4.6.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
https://doi.org/10.5281/zenodo.5772642
(Available online at http://glottolog.org, Accessed on 2022-05-24.)
